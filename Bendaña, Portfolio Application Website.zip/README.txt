Jhon Ralph R. Bendaña - Personal Portfolio

Files:
- index.html: portfolio webpage
- style.css: website design
- TicTacToe.java: two-player console game source code

To preview the website, open index.html in a web browser.
To run the Java game, compile TicTacToe.java and run the TicTacToe class.

Before making the repository public, review your contact details. Avoid publishing a personal phone number, exact home address, or other private information.
