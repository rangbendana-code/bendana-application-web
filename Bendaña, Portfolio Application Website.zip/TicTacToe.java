import java.util.Scanner;

public class TicTacToe {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        char[] board = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};
        char currentPlayer = 'X';
        int moves = 0;
        boolean gameOver = false;

        System.out.println("=== TIC TAC TOE ===");
        System.out.println("Player 1: X");
        System.out.println("Player 2: O");

        while (moves < 9 && !gameOver) {
            System.out.println();
            System.out.println(" " + board[0] + " | " + board[1] + " | " + board[2]);
            System.out.println("---+---+---");
            System.out.println(" " + board[3] + " | " + board[4] + " | " + board[5]);
            System.out.println("---+---+---");
            System.out.println(" " + board[6] + " | " + board[7] + " | " + board[8]);

            System.out.println();
            System.out.println("Player " + currentPlayer + ", choose a number from 1 to 9:");
            int choice = input.nextInt();

            if (choice < 1 || choice > 9) {
                System.out.println("Invalid choice. Please choose from 1 to 9.");
                continue;
            }

            int position = choice - 1;

            if (board[position] == 'X' || board[position] == 'O') {
                System.out.println("That spot is already taken. Try again.");
                continue;
            }

            board[position] = currentPlayer;
            moves++;

            if (board[0] == currentPlayer && board[1] == currentPlayer && board[2] == currentPlayer ||
                board[3] == currentPlayer && board[4] == currentPlayer && board[5] == currentPlayer ||
                board[6] == currentPlayer && board[7] == currentPlayer && board[8] == currentPlayer ||
                board[0] == currentPlayer && board[3] == currentPlayer && board[6] == currentPlayer ||
                board[1] == currentPlayer && board[4] == currentPlayer && board[7] == currentPlayer ||
                board[2] == currentPlayer && board[5] == currentPlayer && board[8] == currentPlayer ||
                board[0] == currentPlayer && board[4] == currentPlayer && board[8] == currentPlayer ||
                board[2] == currentPlayer && board[4] == currentPlayer && board[6] == currentPlayer) {

                System.out.println();
                System.out.println(" " + board[0] + " | " + board[1] + " | " + board[2]);
                System.out.println("---+---+---");
                System.out.println(" " + board[3] + " | " + board[4] + " | " + board[5]);
                System.out.println("---+---+---");
                System.out.println(" " + board[6] + " | " + board[7] + " | " + board[8]);
                System.out.println();
                System.out.println("Player " + currentPlayer + " wins!");
                gameOver = true;
            } else if (moves == 9) {
                System.out.println();
                System.out.println("It's a draw!");
                gameOver = true;
            } else {
                if (currentPlayer == 'X') {
                    currentPlayer = 'O';
                } else {
                    currentPlayer = 'X';
                }
            }
        }

        input.close();
        System.out.println("Thank you for playing!");
    }
}
